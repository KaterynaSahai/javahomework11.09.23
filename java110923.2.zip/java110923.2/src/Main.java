import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        int a, b, c, v;
        System.out.println("Введите первое число");
        a = scr.nextInt();
        System.out.println("Введите второе число");
        b = scr.nextInt();
        System.out.println("Введите результат умножения");
        c = scr.nextInt();
        v = a * b;
        if (c == v) {

            System.out.println("Верно");
        } else {
            System.out.println("ошибка верный ответ " + v);
        }


    }
}