public class Main {
    public static void main(String[] args) {

        int m = 15;
        int n = 20;
        int disM = Math.abs(m - 10);
        int disN = Math.abs(n - 10);
        if (disM < disN) {
            System.out.println(m);
        } else {
            System.out.println(n);
        }


    }
}