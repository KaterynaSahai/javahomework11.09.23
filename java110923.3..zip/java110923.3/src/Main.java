import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("Введите год");
        int year=new Scanner(System.in).nextInt();
        String message=year<1935?"Элвис еще не родился":(year<1977?"Элвис жив":"Элвис навсегда в наших сердцах!");
        System.out.println(message);
    }
}